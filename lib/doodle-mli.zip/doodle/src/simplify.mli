(** Stroke simplifier: reduces a smoothed stroke to 5 to 9 corners.

    Adapted from GIMP's [simplify_subdivide] in [gimpboundary.c]: the
    same cross-product distance test and recursion, but split at the
    farthest point (true Ramer-Douglas-Peucker) instead of GIMP's
    midpoint, with a tolerance relative to the drawing's size.

    Smoothing happens earlier, in {!Capture}. *)

type reason = [ `Too_simple | `Too_complex ]
(** Why a stroke was refused. [main.ml] turns this into the on-screen
    hint, which closes gap G4 in the diagrams. *)

val min_corners : int
(** [5] *)

val max_corners : int
(** [9] *)

val eps_fraction : float
(** Starting tolerance as a fraction of the bounding-box diagonal.
    [0.04]. *)

val line_fraction : float
(** A stroke is a line when no point is farther than this fraction of
    the diagonal from the first-to-last chord. [0.08]. *)

val max_tries : int
(** Number of tolerance adjustments before giving up. [5]. *)

val is_line : Geom.pt array -> bool
(** [true] when the stroke is too close to a straight line to match
    anything distinctive. *)

val rdp : eps:float -> Geom.pt array -> Geom.pt array
(** One run of Ramer-Douglas-Peucker with absolute tolerance [eps]
    (pixels). For each range [\[i, j\]] with [a = pts.(i)] and
    [(dx, dy) = pts.(j) - a], the test value for point [p] is
    [|dx *. (a.y -. p.y) -. dy *. (a.x -. p.x)|], which is the true
    distance times the chord length, so it is compared with
    [eps *. length] and no square root runs inside the loop. When the
    two ends coincide (a closed stroke), plain distance from [a] is
    used instead. Keeps the first and last points. Exposed for tests. *)

val corners : Geom.pt array -> (Geom.pt array, reason) result
(** The full simplifier:
    + [Error `Too_simple] if fewer than 3 points or {!is_line};
    + [eps = eps_fraction *. bbox_diagonal];
    + run {!rdp}; over {!max_corners} raises [eps] by 30%, under
      {!min_corners} lowers it by 30%, at most {!max_tries} times;
    + [Ok corners] when the count lands in range, otherwise
      [Error `Too_complex] (still too many) or [Error `Too_simple]
      (still too few). *)
