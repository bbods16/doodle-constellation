(** Stroke capture: movement filter plus Gaussian smoothing.

    Adapted from GIMP's [gimpmotionbuffer.c] (drop moves too small to
    matter) and [gimp_paint_core_smooth_coords] (Gaussian-weighted mean
    of recent points). raylib gives one sample per frame and no
    per-event timestamps, so the weight falls off with distance back
    along the stroke instead of with accumulated velocity.

    [main.ml] reads [get_mouse_position ()] while the left button is
    down and passes each sample to {!add}. *)

type t
(** The stroke so far: raw kept points and their smoothed versions,
    in drawing order. *)

val min_step : float
(** Minimum distance in pixels from the last kept point before a new
    sample is kept. [2.0]. *)

val window : int
(** Number of recent kept points averaged by the smoother. [8]. *)

val sigma : float
(** Gaussian width in pixels, measured along the stroke. [6.0]. *)

val empty : t

val add : t -> Geom.pt -> t
(** [add t p]:
    + drops [p] if it is less than {!min_step} from the last kept point;
    + otherwise keeps it and appends its smoothed version, the weighted
      mean of the last {!window} kept points with weight
      [exp (-. d *. d /. (2. *. sigma *. sigma))], where [d] is the
      distance back along the stroke from [p]. *)

val stroke : t -> Geom.pt array
(** Smoothed points in drawing order. This is what {!Simplify.corners}
    receives on button release. *)

val raw : t -> Geom.pt array
(** Kept points before smoothing, for debugging and tests. *)

val length : t -> int
(** Number of kept points. *)

val is_empty : t -> bool
