(** Morph animation: slides, turns and scales the drawing onto the stars.

    Interpolates the transform, not the points, the way GIMP's
    [gimp_tool_polygon_fit_segment] moves a whole point list with one
    transform. Pure OCaml; {!Sky} does the drawing. *)

type t

val duration : float
(** Seconds from start to finish. [1.5]. *)

val ease : float -> float
(** Smoothstep: [ease u = u *. u *. (3. -. 2. *. u)] for [u] in [0, 1]. *)

val start : drawn:Geom.pt array -> target:Geom.pt array -> t
(** [start ~drawn ~target] fits the end transform with
    {!Geom.procrustes} from the drawn corners to the matched stars'
    screen positions (falls back to {!Geom.identity} if that fails),
    and records [c0], the centroid of [drawn]. Progress starts at 0. *)

val step : t -> float -> t
(** [step t dt] advances progress by [dt /. duration], capped at 1.
    Pass [get_frame_time ()]. *)

val progress : t -> float
(** Raw progress [u] in [0, 1]. *)

val finished : t -> bool
(** [progress t >= 1.] *)

val current_sim : t -> Geom.sim
(** The blended transform at eased progress [e]: scale [s1 ** e],
    angle [e *. wrap_angle theta1], and the centroid moved in a
    straight line from [c0] to [T1 c0]. *)

val current : t -> Geom.pt array -> Geom.pt array
(** Applies {!current_sim} to any point list, normally every smoothed
    stroke point: [p -> c(e) + s(e) * R(theta(e)) * (p - c0)]. *)

val end_sim : t -> Geom.sim
(** The final transform [T1]. *)
