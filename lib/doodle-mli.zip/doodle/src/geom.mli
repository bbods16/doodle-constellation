(** Shared 2-D geometry for Doodle Constellation.

    Every matching module works on {!pt}, a plain record, never on
    raylib's [Vector2.t]. Only [bin/] converts to raylib types, so this
    library can be tested with [dune test] without opening a window.

    Angles are in radians. Sky coordinates are (right ascension,
    declination) pairs in radians. *)

(** {1 Types} *)

type pt = { x : float; y : float }
(** A point on the screen (pixels) or on a projection plane (radians). *)

type sim = { s : float; theta : float; tx : float; ty : float }
(** A similarity transform: uniform scale [s], rotation [theta] and
    shift [(tx, ty)].  It maps [p] to [s * R(theta) * p + t], where
    [R(theta) p = (cos theta * p.x - sin theta * p.y,
                   sin theta * p.x + cos theta * p.y)]. *)

val identity : sim
(** [{ s = 1.; theta = 0.; tx = 0.; ty = 0. }] *)

(** {1 Point helpers} *)

val add : pt -> pt -> pt
val sub : pt -> pt -> pt
val scale : float -> pt -> pt
val rotate : float -> pt -> pt
(** [rotate theta p] is [R(theta) p]. *)

val dist : pt -> pt -> float
val dist_sq : pt -> pt -> float
val lerp : pt -> pt -> float -> pt
(** [lerp a b u] is [a + u * (b - a)]. *)

val centroid : pt array -> pt
(** Mean of the points. Raises [Invalid_argument] on an empty array. *)

val bbox_diagonal : pt array -> float
(** Length of the diagonal of the axis-aligned bounding box. *)

val wrap_angle : float -> float
(** Brings an angle into (-pi, pi], so blending always takes the
    shorter turn. *)

(** {1 Similarity transforms} *)

val apply : sim -> pt -> pt
(** [apply t p] is [t.s * R(t.theta) * p + (t.tx, t.ty)]. *)

val apply_all : sim -> pt array -> pt array

val sim_of_pair : pt -> pt -> pt -> pt -> sim
(** [sim_of_pair a b a' b'] is the similarity that maps [a] to [a'] and
    [b] to [b'] (the two-handle rule of GIMP's Handle Transform tool):

    - [s = |b' - a'| / |b - a|]
    - [theta = atan2 (b' - a') - atan2 (b - a)]
    - [t = a' - s * R(theta) * a]

    Raises [Invalid_argument] when [a] and [b] coincide. *)

val procrustes : pt array -> pt array -> sim option
(** [procrustes p q] is the least-squares similarity mapping [p.(i)]
    onto [q.(i)] for every [i] (closed-form 2-D Procrustes):

    - centre both sets: [p' = p - c_p], [q' = q - c_q]
    - [a = sum (p'x * q'x + p'y * q'y)], [b = sum (p'x * q'y - p'y * q'x)]
    - [theta = atan2 b a], [s = sqrt (a^2 + b^2) / sum |p'|^2]
    - [t = c_q - s * R(theta) * c_p]

    Returns [None] when the arrays differ in length, have fewer than 2
    points, or [sum |p'|^2 < 1e-9] (compare with an epsilon, never with
    exact zero). *)

val rms : sim -> pt array -> pt array -> float
(** [rms t p q] is [sqrt (mean |apply t p.(i) - q.(i)|^2)]. *)

val mirror_y : pt array -> pt array
(** Reflects every point through the x axis ([y -> -y]), for the
    optional mirror pass in {!Fitter}. *)

(** {1 Sky projections} *)

val gnomonic : centre:float * float -> float * float -> pt option
(** [gnomonic ~centre (ra, dec)] projects a sky position onto the plane
    tangent to the sky at [centre]. Straight lines on the sky stay
    straight, so flat-geometry shape keys are valid for small patches.
    Returns [None] for positions 90 degrees or more from [centre]. *)

val angular_sep : float * float -> float * float -> float
(** Great-circle distance between two sky positions, in radians. *)

val deg : float -> float
(** Radians to degrees. *)

val rad : float -> float
(** Degrees to radians. *)
