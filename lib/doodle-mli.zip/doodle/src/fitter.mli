(** Similarity fitter and scorer.

    Tests each hypothesis against every corner: snap each corner to the
    nearest unused star within a radius (running minimum, as in GIMP's
    [gimp_image_snap_point]), refit with {!Geom.procrustes}, repeat,
    then score. Least-squares Procrustes is new code; GIMP only solves
    exact 4-point transforms. *)

type fit = {
  stars : int array;       (** one star index per corner, in corner order *)
  sim : Geom.sim;          (** screen pixels onto the gnomonic plane *)
  centre : float * float;  (** (ra, dec) of that plane *)
  rms_deg : float;         (** root-mean-square corner-to-star gap, degrees *)
  score : float;           (** [rms_deg] plus penalties; lower is better *)
  mirrored : bool;         (** [true] if the reflected drawing fitted better *)
  weak : bool;             (** [rms_deg > accept_limit] *)
}

val accept_limit : float
(** Largest RMS error, in degrees, that counts as a good match. The
    fitter owns this rule, which closes gap G3. [3.0]. *)

val snap_radius_deg : float
(** A corner only snaps to a star within this distance. [4.0]. *)

val passes : int
(** Snap-and-refit rounds per hypothesis. [3]. *)

val allow_mirror : bool
(** Also try the drawing reflected with {!Geom.mirror_y}. [true]. *)

val faint_penalty : float
(** Added per magnitude fainter than 3.0, summed over matched stars. *)

val unused_bright_penalty : float
(** Added per star brighter than the faintest matched star that lies
    inside the shape but was not used. *)

val snap :
  Catalogue.star array -> centre:float * float -> Geom.pt array ->
  int array option
(** [snap stars ~centre pts] gives, for each projected corner, the
    nearest star within {!snap_radius_deg} not already taken by an
    earlier corner. [None] if any corner has no star in range. *)

val fit_one : Catalogue.star array -> Candidates.hypothesis -> fit option
(** One hypothesis, {!passes} rounds of {!snap} then
    {!Geom.procrustes}. [None] if snapping fails or Procrustes rejects
    a degenerate set. *)

val best : Catalogue.star array -> Candidates.hypothesis list -> fit option
(** Runs {!fit_one} on every hypothesis (and the mirrored drawing when
    {!allow_mirror}) and keeps the lowest [score]. [None] only when no
    hypothesis could be fitted at all; a poor fit is returned with
    [weak = true]. *)
