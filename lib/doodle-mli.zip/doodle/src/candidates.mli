(** Candidate generator: turns drawn corners into guesses.

    For each drawn triangle, looks up {!Index.find_near} and, for each
    star triple found, derives a first transform with
    {!Geom.sim_of_pair} from the triangle's longest side (the steadiest
    baseline), the two-handle rule from GIMP's Handle Transform tool. *)

type hypothesis = {
  drawn : Geom.pt array;   (** all simplified corners, screen pixels *)
  corners : int array;     (** the 3 seed corners, canonical order *)
  stars : int array;       (** the 3 seed stars, same order *)
  centre : float * float;  (** (ra, dec) of the gnomonic plane used *)
  sim : Geom.sim;          (** maps screen pixels onto that plane *)
}

val max_hypotheses : int
(** Cap on the list length so the fitter stays fast. [5000]. *)

val triangles : int -> (int * int * int) list
(** [triangles n] lists every 3-subset of [0 .. n-1] (84 for [n = 9]). *)

val generate : Index.t -> Geom.pt array -> hypothesis list
(** [generate index corners]:
    + forms every triangle of [corners];
    + computes {!Index.key} and looks up {!Index.find_near};
    + projects each hit's stars with {!Geom.gnomonic} around the
      triple's centroid;
    + pairs the drawn longest side [(a, b)] with the star longest side
      [(a', b')] and sets [sim = Geom.sim_of_pair a b a' b'].
    Holds no state between drawings. *)
