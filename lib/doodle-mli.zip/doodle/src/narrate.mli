(** Narration layer (optional, not in the two-hour build).

    Asks a language model for a short invented myth built only from the
    facts passed in. Runs in its own [Domain] so the raylib frame loop
    never waits on the network. *)

type request = {
  shape : string;          (** the user's name for the drawing, e.g. ["Bolt"] *)
  stars : string list;     (** matched star labels *)
  neighbour : string;      (** nearest official constellation *)
}

val prompt : request -> string
(** The text sent to the model: only these facts, no numbers beyond
    them, and an instruction to write about 70 words. *)

val fiction_label : string
(** ["This story is invented."], shown with every story. *)

val story : shape:string -> stars:string list -> string option
(** Blocking call. [None] if the service is unreachable, in which case
    the app simply shows no story. *)

val story_async : request -> (string option -> unit) -> unit
(** Runs {!story} in a new [Domain] and calls the callback with the
    result. The callback must only store the result; drawing happens on
    the main loop. *)
