(** Visibility calculator: when and where the match is best seen.

    Pure float maths. Latitude and longitude come from command-line
    arguments (Buffalo by default) and the time from
    [Unix.gettimeofday ()], which closes gap G2. Angles in radians,
    times in Unix seconds, longitude positive east. No GIMP counterpart. *)

val buffalo : float * float
(** Default [(lat, lon)]: about 42.89 N, 78.88 W. *)

val local_sidereal_time : lon:float -> now:float -> float
(** Local sidereal time as an angle in [0, 2 pi). *)

val hour_angle : lon:float -> ra:float -> now:float -> float
(** In (-pi, pi]; zero when the position crosses the meridian. *)

val altitude : lat:float -> lon:float -> ra:float -> dec:float -> now:float -> float
(** Height above the horizon. *)

val azimuth : lat:float -> lon:float -> ra:float -> dec:float -> now:float -> float
(** Compass direction, measured from north through east. *)

val culmination : lon:float -> ra:float -> now:float -> float
(** The next time at or after [now] when the hour angle is zero. *)

val sun_altitude : lat:float -> lon:float -> now:float -> float
(** Approximate Sun altitude, good to about a degree, enough for a
    darkness check. *)

val is_dark : lat:float -> lon:float -> now:float -> bool
(** Sun more than 12 degrees below the horizon (nautical twilight). *)

val best_view :
  lat:float -> lon:float -> ra:float -> dec:float -> now:float ->
  float * float * float
(** [(time, altitude, azimuth)] for the best time in the next 24 hours:
    the culmination if it falls in darkness, otherwise the dark moment
    when the region stands highest. *)

val compass : float -> string
(** Azimuth to an 8-point label, e.g. ["south"]. *)
