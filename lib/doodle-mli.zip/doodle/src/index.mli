(** Invariant index: geometric hashing of star triangles.

    Every triangle of stars within {!max_sep_deg} of each other is
    projected with {!Geom.gnomonic} around its own centroid and
    described by a key that ignores position, size and rotation. The
    same {!key} function is used for drawn corners, so drawn and
    catalogued shapes land in the same bins. No GIMP counterpart; the
    design follows Astrometry.net. *)

type key = int * int * int
(** Binned (short/long side ratio, middle/long side ratio, angle
    opposite the longest side). *)

type triple = int * int * int
(** Star indices into the catalogue array, ordered like the key:
    the vertices opposite the short, middle and long sides. *)

type t

val ratio_bins : int
(** Bins across [0, 1] for each side ratio. [40]. *)

val angle_bins : int
(** Bins across [0, pi] for the angle. [36] (5 degrees each). *)

val max_sep_deg : float
(** Largest angular distance between two stars of one triangle. [25.]. *)

val key : Geom.pt -> Geom.pt -> Geom.pt -> key * int array
(** [key a b c] is the binned shape key of the triangle and the
    permutation [\[|i; j; k|\]] of [0, 1, 2] that puts its vertices in
    canonical order (opposite the short, middle and long sides).
    Raises [Invalid_argument] for a degenerate triangle. *)

val neighbours : key -> key list
(** The key and its 26 neighbours ([+-1] in each part), clamped to the
    valid ranges. *)

val build : Catalogue.star array -> t
(** Builds the index once at startup. *)

val stars : t -> Catalogue.star array
(** The catalogue the index was built from. *)

val find : t -> key -> triple list
(** Triples filed under exactly this key. *)

val find_near : t -> key -> triple list
(** Triples filed under the key or any of its {!neighbours}, which
    tolerates a shaky hand. *)

val size : t -> int
(** Number of triples stored. *)
