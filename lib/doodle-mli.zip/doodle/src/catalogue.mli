(** Star catalogue store: the bright stars the matcher may use.

    Loaded once at startup from a CSV file with the header
    [id,name,ra_deg,dec_deg,mag,con]. No GIMP counterpart. *)

type star = {
  id : int;
  name : string;  (** proper name, or [""] when the star has none *)
  ra : float;     (** right ascension, radians *)
  dec : float;    (** declination, radians *)
  mag : float;    (** apparent magnitude; smaller is brighter *)
  con : string;   (** three-letter constellation abbreviation, e.g. ["Ori"] *)
}

val default_max_mag : float
(** Brightness cut: [4.5]. Fainter stars are hard to find from a city. *)

val parse_line : string -> star option
(** Parses one CSV row (degrees in the file, radians in the record).
    [None] for the header, blank lines and malformed rows. *)

val load : ?max_mag:float -> string -> star array
(** [load path] reads the file with [In_channel], keeps stars with
    [mag <= max_mag] (default {!default_max_mag}), and returns them in
    file order. Array indices are the star indices used everywhere
    else. Raises [Sys_error] if the file is missing. *)

val position : star -> float * float
(** [(ra, dec)]. *)

val label : star -> string
(** The name if there is one, otherwise ["HR " ^ string_of_int id]. *)
